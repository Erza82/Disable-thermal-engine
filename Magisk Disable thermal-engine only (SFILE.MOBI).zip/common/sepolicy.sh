# Put sepolicy statements here
# Example: allow { audioserver mediaserver } 
